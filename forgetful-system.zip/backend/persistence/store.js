
const Memory = require('../domain/memory');
const { decay } = require('../decay/engine');

let memories = [
  new Memory({
    id: '1',
    type: 'core',
    value: 'You like coffee',
    confidence: 0.9,
    decayRate: 0.000001,
    lastReinforced: Date.now()
  })
];

function getAll() {
  memories = memories.map(m => decay(m, Date.now() - m.lastReinforced));
  return memories;
}

function reinforce(id) {
  const m = memories.find(x => x.id === id);
  if (!m) return null;
  m.confidence = Math.min(1, m.confidence + 0.1);
  m.lastReinforced = Date.now();
  return m;
}

module.exports = { getAll, reinforce };
