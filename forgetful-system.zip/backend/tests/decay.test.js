
const { decay } = require('../decay/engine');

test('confidence decays over time', () => {
  const m = { confidence: 1, decayRate: 0.001, value: 'x', mutations: [] };
  const d = decay(m, 1000);
  expect(d.confidence).toBeLessThan(1);
});
