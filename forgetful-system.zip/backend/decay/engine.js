
function decay(memory, elapsedMs) {
  const decayFactor = Math.exp(-memory.decayRate * elapsedMs);
  let confidence = memory.confidence * decayFactor;

  if (Math.random() < 0.05) {
    memory.mutations.push('drift');
    memory.value = memory.value + ' (misremembered)';
    confidence = Math.min(1, confidence + 0.2);
  }

  return { ...memory, confidence };
}
module.exports = { decay };
