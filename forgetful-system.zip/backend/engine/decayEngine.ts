import { Memory } from "../domain/Memory";

export function decayMemory({
  memory,
  elapsedMs,
  reinforcement = false,
  attemptedCorrection,
  rng
}: {
  memory: Memory;
  elapsedMs: number;
  reinforcement?: boolean;
  attemptedCorrection?: string;
  rng: () => number;
}): Memory {
  const elapsedDays = elapsedMs / (1000 * 60 * 60 * 24);
  let confidence = memory.confidence * Math.exp(-memory.decayRate * elapsedDays);
  let value = memory.value;

  if (reinforcement) {
    confidence += (1 - confidence) * 0.4 * rng();
  }

  if (attemptedCorrection && rng() < 0.35) {
    if (rng() < 0.5) value = attemptedCorrection;
  }

  if (rng() < 0.05 * elapsedDays) {
    value = value + " (approximately)";
  }

  return {
    ...memory,
    value,
    confidence: Math.max(0, Math.min(1, confidence)),
    mutationHistory: memory.mutationHistory.concat({
      timestamp: Date.now(),
      kind: "decay"
    })
  };
}