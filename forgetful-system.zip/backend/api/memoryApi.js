
const express = require('express');
const router = express.Router();
const store = require('../persistence/store');

router.get('/memories', (req, res) => {
  res.json(store.getAll());
});

router.post('/reinforce', (req, res) => {
  const { id } = req.body;
  res.json(store.reinforce(id));
});

module.exports = router;
