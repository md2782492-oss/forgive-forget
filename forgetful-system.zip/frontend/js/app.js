
const API = '/api';

async function loadMemories() {
  const res = await fetch(API + '/memories');
  const memories = await res.json();
  const list = document.getElementById('memory-list');
  list.innerHTML = '';
  memories.forEach(m => {
    const li = document.createElement('li');
    li.textContent = m.value;
    li.onclick = () => showDetail(m);
    list.appendChild(li);
  });
}

function showDetail(memory) {
  const d = document.getElementById('detail');
  d.innerHTML = `<p>${memory.value}</p><small>${memory.confidence > 0.7 ? 'Certain' : 'Uncertain'}</small>`;
}

loadMemories();
